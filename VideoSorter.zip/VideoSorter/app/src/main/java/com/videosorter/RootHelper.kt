package com.videosorter

import com.topjohnwu.superuser.Shell

object RootHelper {

    /**
     * Jalankan perintah shell dengan root
     * Kembalikan output sebagai String
     */
    fun exec(command: String): String {
        val result = Shell.cmd(command).exec()
        return if (result.isSuccess) {
            result.out.joinToString("\n")
        } else {
            "ERROR: ${result.err.joinToString("\n")}"
        }
    }

    /**
     * Cek apakah path adalah direktori
     */
    fun isDirectory(path: String): Boolean {
        val result = Shell.cmd("[ -d \"$path\" ] && echo yes || echo no").exec()
        return result.out.firstOrNull()?.trim() == "yes"
    }

    /**
     * Buat folder jika belum ada
     */
    fun mkdirIfNotExists(path: String) {
        Shell.cmd("mkdir -p \"$path\"").exec()
    }

    /**
     * Pindahkan file ke folder tujuan
     */
    fun moveFile(sourcePath: String, destDir: String): Boolean {
        mkdirIfNotExists(destDir)
        val result = Shell.cmd("mv \"$sourcePath\" \"$destDir/\"").exec()
        return result.isSuccess
    }

    /**
     * Daftar semua file video di suatu folder (rekursif)
     * Extension: mp4, mov, avi, mkv, webm, 3gp
     */
    fun listVideoFiles(directory: String): List<String> {
        val cmd = "find \"$directory\" -type f \\( " +
                "-iname \"*.mp4\" -o -iname \"*.mov\" -o -iname \"*.avi\" " +
                "-o -iname \"*.mkv\" -o -iname \"*.webm\" -o -iname \"*.3gp\" \\)"
        val result = Shell.cmd(cmd).exec()
        return if (result.isSuccess) result.out.filter { it.isNotBlank() } else emptyList()
    }

    /**
     * Media scan file supaya muncul di galeri
     */
    fun mediaScan(path: String) {
        Shell.cmd("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d \"file://$path\"").exec()
    }
}
