package com.videosorter

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.topjohnwu.superuser.Shell

class MainActivity : AppCompatActivity() {

    private lateinit var tvRootStatus: TextView
    private lateinit var tvServiceStatus: TextView
    private lateinit var btnToggleService: Button
    private lateinit var btnSortNow: Button
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvRootStatus    = findViewById(R.id.tvRootStatus)
        tvServiceStatus = findViewById(R.id.tvServiceStatus)
        btnToggleService = findViewById(R.id.btnToggleService)
        btnSortNow      = findViewById(R.id.btnSortNow)
        logView         = findViewById(R.id.logView)

        checkRootAccess()

        btnToggleService.setOnClickListener { toggleService() }
        btnSortNow.setOnClickListener { sortNow() }
    }

    private fun checkRootAccess() {
        Shell.getShell { shell ->
            val hasRoot = shell.isRoot
            runOnUiThread {
                if (hasRoot) {
                    tvRootStatus.text = "✅ Root: Aktif"
                    tvRootStatus.setTextColor(getColor(android.R.color.holo_green_dark))
                    btnToggleService.isEnabled = true
                    btnSortNow.isEnabled = true
                    appendLog("Root access berhasil didapatkan.")
                } else {
                    tvRootStatus.text = "❌ Root: Tidak Ada"
                    tvRootStatus.setTextColor(getColor(android.R.color.holo_red_dark))
                    btnToggleService.isEnabled = false
                    btnSortNow.isEnabled = false
                    appendLog("GAGAL: Root tidak tersedia di perangkat ini.")
                }
            }
        }
    }

    private fun toggleService() {
        val isRunning = VideoSorterService.isRunning
        if (isRunning) {
            stopService(Intent(this, VideoSorterService::class.java))
            tvServiceStatus.text = "⏹ Service: Berhenti"
            btnToggleService.text = "Mulai Service"
            appendLog("Service dihentikan.")
        } else {
            startForegroundService(Intent(this, VideoSorterService::class.java))
            tvServiceStatus.text = "▶ Service: Berjalan"
            btnToggleService.text = "Hentikan Service"
            appendLog("Service dimulai. Memantau video baru...")
        }
    }

    private fun sortNow() {
        appendLog("Memulai sortir manual semua video...")
        Thread {
            val result = VideoSorterService.sortAllVideos()
            runOnUiThread { appendLog(result) }
        }.start()
    }

    fun appendLog(msg: String) {
        val current = logView.text.toString()
        logView.text = "• $msg\n$current"
    }

    override fun onResume() {
        super.onResume()
        if (VideoSorterService.isRunning) {
            tvServiceStatus.text = "▶ Service: Berjalan"
            btnToggleService.text = "Hentikan Service"
        } else {
            tvServiceStatus.text = "⏹ Service: Berhenti"
            btnToggleService.text = "Mulai Service"
        }
    }
}
