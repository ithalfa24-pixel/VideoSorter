package com.videosorter

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

class VideoSorterService : Service() {

    companion object {
        var isRunning = false
        const val CHANNEL_ID = "VideoSorterChannel"
        const val NOTIF_ID = 1

        // =============================================
        // FOLDER SUMBER — sesuaikan dengan HP kamu
        // =============================================
        val SOURCE_FOLDERS = mapOf(
            "Instagram"  to listOf(
                "/sdcard/Pictures/Instagram",
                "/sdcard/DCIM/Instagram",
                "/sdcard/Android/data/com.instagram.android/files"
            ),
            "WhatsApp"   to listOf(
                "/sdcard/WhatsApp/Media/WhatsApp Video",
                "/sdcard/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
            ),
            "YouTube"    to listOf(
                "/sdcard/Movies/YouTube",
                "/sdcard/Android/data/com.google.android.youtube/files"
            ),
            "Telegram"   to listOf(
                "/sdcard/Telegram/Telegram Video",
                "/sdcard/Android/data/org.telegram.messenger/files/Telegram/Telegram Video"
            ),
            "Facebook"   to listOf(
                "/sdcard/DCIM/Facebook",
                "/sdcard/Pictures/Facebook"
            ),
            "Twitter"    to listOf(
                "/sdcard/Pictures/Twitter",
                "/sdcard/Android/data/com.twitter.android/files/images/media"
            )
        )

        // =============================================
        // FOLDER TUJUAN — tempat video akan dipindah
        // =============================================
        const val DEST_BASE = "/sdcard/Videos/Sorted"

        // =============================================
        // FOLDER KAMERA — tempat TikTok menyimpan video
        // =============================================
        val CAMERA_FOLDERS = listOf(
            "/sdcard/DCIM/Camera",
            "/sdcard/DCIM/100ANDRO"
        )

        // =============================================
        // Deteksi nama file TikTok (format MD5: 32 karakter hex)
        // Contoh: 43c4514d186be53c3438f1c8690b0a47.mp4
        // =============================================
        fun isTikTokFile(fileName: String): Boolean {
            val name = fileName.substringBeforeLast(".")
            val ext = fileName.substringAfterLast(".").lowercase()
            // TikTok: nama file 32 karakter hex (MD5 hash)
            return ext == "mp4" && name.matches(Regex("[a-f0-9]{32}"))
        }

        fun sortAllVideos(): String {
            var totalMoved = 0
            val log = StringBuilder()

            // ---- Sortir dari folder biasa ----
            for ((appName, sourceFolders) in SOURCE_FOLDERS) {
                val destDir = "$DEST_BASE/$appName"
                for (sourceDir in sourceFolders) {
                    if (!RootHelper.isDirectory(sourceDir)) continue

                    val videos = RootHelper.listVideoFiles(sourceDir)
                    for (videoPath in videos) {
                        if (videoPath.startsWith(DEST_BASE)) continue

                        val success = RootHelper.moveFile(videoPath, destDir)
                        if (success) {
                            totalMoved++
                            val fileName = videoPath.substringAfterLast("/")
                            log.appendLine("✅ [$appName] $fileName")
                            RootHelper.mediaScan("$destDir/$fileName")
                        } else {
                            val fileName = videoPath.substringAfterLast("/")
                            log.appendLine("❌ GAGAL: $fileName")
                        }
                    }
                }
            }

            // ---- Deteksi TikTok dari DCIM/Camera berdasarkan nama file MD5 ----
            val tiktokDestDir = "$DEST_BASE/TikTok"
            for (cameraDir in CAMERA_FOLDERS) {
                if (!RootHelper.isDirectory(cameraDir)) continue

                val videos = RootHelper.listVideoFiles(cameraDir)
                for (videoPath in videos) {
                    if (videoPath.startsWith(DEST_BASE)) continue

                    val fileName = videoPath.substringAfterLast("/")
                    if (isTikTokFile(fileName)) {
                        val success = RootHelper.moveFile(videoPath, tiktokDestDir)
                        if (success) {
                            totalMoved++
                            log.appendLine("✅ [TikTok] $fileName")
                            RootHelper.mediaScan("$tiktokDestDir/$fileName")
                        } else {
                            log.appendLine("❌ GAGAL TikTok: $fileName")
                        }
                    }
                }
            }

            return if (totalMoved > 0) {
                "Selesai! $totalMoved video dipindahkan.\n$log"
            } else {
                "Tidak ada video baru yang perlu disortir."
            }
        }
    }

    private var watcherThread: Thread? = null
    private var isWatching = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isRunning = true
        startForeground(NOTIF_ID, buildNotification("Memantau video baru..."))
        startWatcher()
        return START_STICKY
    }

    private fun startWatcher() {
        isWatching = true
        watcherThread = Thread {
            Log.d("VideoSorter", "Watcher dimulai")
            while (isWatching) {
                try {
                    val result = sortAllVideos()
                    if (!result.startsWith("Tidak ada")) {
                        Log.d("VideoSorter", result)
                        updateNotification("Video baru disortir!")
                        Thread.sleep(3000)
                        updateNotification("Memantau video baru...")
                    }
                    // Cek setiap 30 detik
                    Thread.sleep(30_000)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e("VideoSorter", "Error: ${e.message}")
                }
            }
        }
        watcherThread?.start()
    }

    override fun onDestroy() {
        isRunning = false
        isWatching = false
        watcherThread?.interrupt()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Video Sorter",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Service untuk sortir video otomatis"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Video Sorter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(text))
    }
}
