package com.videosorter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Restart service otomatis setelah HP reboot
            val serviceIntent = Intent(context, VideoSorterService::class.java)
            context.startForegroundService(serviceIntent)
        }
    }
}
