# 🎬 Video Sorter - Panduan Setup

Aplikasi Android untuk sortir video otomatis berdasarkan sumbernya (TikTok, Instagram, WhatsApp, dll).
Membutuhkan **akses root**.

---

## 📁 Struktur File

```
VideoSorter/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/videosorter/
│       │   ├── MainActivity.kt        ← UI utama
│       │   ├── VideoSorterService.kt  ← Background service + logika sortir
│       │   ├── RootHelper.kt          ← Utilitas perintah root
│       │   └── BootReceiver.kt        ← Auto-start saat reboot
│       └── res/layout/
│           └── activity_main.xml      ← Tampilan UI
├── build.gradle
└── settings.gradle
```

---

## ⚙️ Cara Setup di Android Studio (PC)

1. Buka Android Studio → **Open Project** → pilih folder `VideoSorter`
2. Tunggu Gradle sync selesai (butuh internet untuk download library)
3. Colok HP ke PC via USB, aktifkan **USB Debugging**
4. Klik **Run** (▶)

---

## ⚙️ Cara Setup di AIDE (langsung di HP)

1. Install **AIDE** dari Play Store
2. Copy semua file ke HP
3. Buka AIDE → Open Project → pilih folder `VideoSorter`
4. Klik **Build & Run**

> **Catatan AIDE**: AIDE mungkin tidak support Gradle sepenuhnya.
> Disarankan pakai **Android Studio** di PC untuk hasil terbaik.

---

## 📂 Folder yang Dipantau

| Aplikasi   | Folder Sumber                                          |
|------------|--------------------------------------------------------|
| TikTok     | `/sdcard/DCIM/TikTok`, `/sdcard/Pictures/TikTok`       |
| Instagram  | `/sdcard/Pictures/Instagram`, `/sdcard/DCIM/Instagram` |
| WhatsApp   | `/sdcard/WhatsApp/Media/WhatsApp Video`                |
| YouTube    | `/sdcard/Movies/YouTube`                               |
| Telegram   | `/sdcard/Telegram/Telegram Video`                      |
| Facebook   | `/sdcard/DCIM/Facebook`                                |
| Twitter    | `/sdcard/Pictures/Twitter`                             |

---

## 📂 Folder Tujuan

Semua video akan dipindah ke:
```
/sdcard/Videos/Sorted/
├── TikTok/
├── Instagram/
├── WhatsApp/
├── YouTube/
├── Telegram/
├── Facebook/
└── Twitter/
```

---

## 🔧 Kustomisasi

Untuk menambah/mengubah folder, edit bagian ini di `VideoSorterService.kt`:

```kotlin
val SOURCE_FOLDERS = mapOf(
    "NamaApp" to listOf(
        "/sdcard/path/folder/nya"
    )
)
```

---

## ⚠️ Catatan Penting

- Aplikasi ini **membutuhkan root**
- Pastikan HP sudah di-root dengan **Magisk** atau **SuperSU**
- Service berjalan di background setiap **30 detik** mengecek video baru
- Service akan **restart otomatis** setelah HP reboot
- Video yang sudah dipindah tidak akan dipindah lagi
